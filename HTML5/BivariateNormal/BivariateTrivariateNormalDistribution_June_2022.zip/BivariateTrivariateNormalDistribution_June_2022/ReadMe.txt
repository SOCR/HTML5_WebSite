SOCR Bivariate/Trivariate Probability Distribution Calculators

Website:  https://socr.umich.edu

App:      https://socr.umich.edu/HTML5/BivariateNormal/TVN/

Code:     https://github.com/SOCR/SOCR_Bivariate_Distributions/tree/master/code

References:

* Bobrovnikov, M, Chai, JT, and Dinov, ID. (2022) Interactive Visualization and Computation of 2D and 3D Probability Distributions, SN Computer Science, DOI: 10.1007/s42979-022-01206-w, in press.

* Chai, JT, Bobrovnikov, M, and Dinov, ID. (2022) Probability Distributome - Computing, Visualization, and Instruction, IASE 2021 Conference Proceedings, Statistics Education in the Era of Data Science, DOI: 10.52041/iase.pdsxt, online first.

* Dinov, ID, Kamino, S, Bhakhrani, B, Christou, N. (2013) Technology-enhanced Interactive Teaching of Marginal, Joint and Conditional Probabilities: The Special Case of Bivariate Normal Distribution, Teaching Statistics, 35(3):131–139, DOI: 10.1111/test.12012.